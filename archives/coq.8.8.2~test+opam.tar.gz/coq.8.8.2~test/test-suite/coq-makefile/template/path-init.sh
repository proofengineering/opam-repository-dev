set -e
set -o pipefail

export PATH="$COQBIN:$PATH"
export LC_ALL=C
