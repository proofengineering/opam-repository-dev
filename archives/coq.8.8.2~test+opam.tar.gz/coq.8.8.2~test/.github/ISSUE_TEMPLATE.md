<!-- Thank you for your contribution.
     Please complete the following information when reporting a bug. -->

#### Version

<!-- You can get this information by running `coqtop -v`. -->


#### Operating system


#### Description of the problem

<!-- It is helpful to provide enough information so that we can reproduce the bug.
     In particular, please include a code example which produces it.
     If the example is small, you can include it here between ``` ```.
     Otherwise, please provide a link to a repository, a gist (https://gist.github.com)
     or drag-and-drop a `.zip` archive. -->
