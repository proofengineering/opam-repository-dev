.. _credits:

.. include:: credits-contents.rst
