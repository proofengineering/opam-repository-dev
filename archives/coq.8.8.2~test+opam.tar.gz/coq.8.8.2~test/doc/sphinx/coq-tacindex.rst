:orphan:

.. hack to get index in TOC

-------------
Tactic index
-------------
